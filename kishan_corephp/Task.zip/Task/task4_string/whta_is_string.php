<?php
/*
    A string is a set of character that is called string.

    A string can be stored in a (single) '' or (double) "" quotation.

    Example:-

    $name="Hello i am kishan";
    $name1="i am studying php";
    $a=391982;

*/
?>