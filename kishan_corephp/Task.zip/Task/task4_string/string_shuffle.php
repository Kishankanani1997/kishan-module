<?php
// Syntax of String shuffle: str_shuffle(string);
echo str_shuffle("how are you");
?>