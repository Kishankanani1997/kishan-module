<?php
function test(&$test1) // here referenced is passed in the function.
{
    echo "My developing language is : PHP"."<br>";
}    
    $test2="PHP is : server side language";

    test ($test1);
    echo $test2;
?>