<?php
$name=array("a"=>"mitesh","b"=>"ramesh","c"=>"shyam","d"=>"ellary","e"=>"sandip","f"=>"yash");
$name1=array("a"=>"ram","b"=>"james","c"=>"hudson");
$name2=array("a"=>"ricky","b"=>"paul","c"=>"ellary","d"=>"lilly","e"=>"arun");
$name3=array("a"=>"shaun","b"=>"jayesh");

print_r(array_merge($name,$name1,$name2,$name3));