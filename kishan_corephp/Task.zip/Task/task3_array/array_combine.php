<?php
$arr=array(0,1,2,3,4,5,6);
$arr1=array("ramesh","hitesh","rakesh","suresh","shyam","hiren","mayur");
print_r(array_combine($arr,$arr1));
?>