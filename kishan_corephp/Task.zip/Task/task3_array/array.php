<?php
/*
ARRAY:- An array is a special variable, which can hold more than one value at a time.
        Array is a variable where we stored a multiple data in a single variable there we used array.

   Initialization of array    

   ["0"]=>["kishan"] 
    key      value
*/
$arr=array(0=>"kishan",1=>"patel",2=>"html",3=>"css");
print_r($arr)."<br>";
print_r($arr[1]);
?>