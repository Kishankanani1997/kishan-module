<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Palindrome Number</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>
<body bgcolor="lightgrey">
    <center>
        <form method="post">
            Enter any Number:-
            <input type="text" name="number" placeholder="Enter any Number:">
            <input type="submit" name="submit" value="submit">
        </form>
    </center>

    <?php
    if(isset($_POST["submit"]))
    {
        $number=$_POST["number"];
        $reverse=strrev($number);

        if($number==$reverse)
        {
            echo "The Number is Palindrome Number";
        }
        else
        {
            echo "The Number is not a Palindrome Number";
        }
    }
    ?>
</body>
</html>