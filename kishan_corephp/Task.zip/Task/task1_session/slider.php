 <!--SLIDER START-->
 <div class="mypostion">
	  <div id="wowslider-container1">
      <div class="ws_images"><ul>
        <li><img src="data1/images/slider1.jpg" alt="slider-1" title="slider-1" id="wows1_0"/></li>
        <li><img src="data1/images/slider2.jpg" alt="slider-2" title="slider-2" id="wows1_1"/></li>
        <li><img src="data1/images/slider3.jpg" alt="slider-3" title="slider-3" id="wows1_2"/></li>
        <li><a href="http://wowslider.net"><img src="data1/images/slider4.jpg" alt="javascript slideshow" title="slider-4" id="wows1_3"/></a></li>
        <li><img src="data1/images/slider5.jpg" alt="slider-5" title="slider-5" id="wows1_4"/></li>
      </ul></div>
      <div class="ws_bullets"><div>
        <a href="#" title="slider-1"><span><img src="data1/tooltips/slider1.jpg" alt="slider-1"/>1</span></a>
        <a href="#" title="slider-2"><span><img src="data1/tooltips/slider2.jpg" alt="slider-2"/>2</span></a>
        <a href="#" title="slider-3"><span><img src="data1/tooltips/slider3.jpg" alt="slider-3"/>3</span></a>
        <a href="#" title="slider-4"><span><img src="data1/tooltips/slider4.jpg" alt="slider-4"/>4</span></a>
        <a href="#" title="slider-5"><span><img src="data1/tooltips/slider5.jpg" alt="slider-5"/>5</span></a>
      </div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">javascript slider</a> by WOWSlider.com v9.0</div>
      <div class="ws_shadow"></div>
      </div>	
      <script type="text/javascript" src="engine1/wowslider.js"></script>
      <script type="text/javascript" src="engine1/script.js"></script>
      </div>
    <!--SLIDER END-->