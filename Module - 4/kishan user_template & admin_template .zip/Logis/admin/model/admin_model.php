<?php
    class admin_model
    {
        public function __construct()
        {
            // database connection
        }

    }
?>