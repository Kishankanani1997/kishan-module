<?php
    require_once("controller/admin_controller.php")
?>