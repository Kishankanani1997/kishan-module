<?php
    class item
    {
        public function __construct()
        {
            // database connection
        }
    }

?>