<div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="<?php echo $baseurl; ?>/images/slider/slider1.jpg" class="d-block w-100" alt="">
    </div>
    <div class="carousel-item">
      <img src="<?php echo $baseurl; ?>/images/slider/slider2.jpg" class="d-block w-100" alt="">
    </div>
    <div class="carousel-item">
      <img src="<?php echo $baseurl; ?>/images/slider/slider3.jpg" class="d-block w-100" alt="">
    </div>
    <div class="carousel-item">
      <img src="<?php echo $baseurl; ?>/images/slider/slider4.jpg" class="d-block w-100" alt="">
    </div>
    <div class="carousel-item">
      <img src="<?php echo $baseurl; ?>/images/slider/slider5.jpg" class="d-block w-100" alt="">
    </div>
  </div>
</div>



