<main id="main">
    <!-- ======= Featured Services Section ======= -->
    <section id="featured-services" class="featured-services">
      <div class="container">
        <div class="row gy-4">
            <a href="<?php echo $mainurl; ?>"><img src="<?php echo $baseurl; ?>/img/404error.gif" class="img-fluid"></a>
        </div>
      </div>
    </section><!-- End Frequently Asked Questions Section -->

  </main><!-- End #main -->